(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics.current_flow_from_to_battery', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics.current_flow_from_to_battery', {
          url: '/current_flow_from_to_battery',
          templateUrl: 'app/pages/batteryanalytics/current_flow_from_to_battery/current_flow_from_to_battery.html',
          title: 'Current Flow',
          sidebarMeta: {
			//icon: 'ion-ios-cart',
            order: 700,
          },
        });
  }

})();