(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics.temperature', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics.temperature', {
          url: '/temperature',
          templateUrl: 'app/pages/batteryanalytics/temperature/temperature.html',
          title: 'Temperature',
          sidebarMeta: {
			//icon: 'ion-ios-cart',
            order: 300,
          },
        });
  }

})();