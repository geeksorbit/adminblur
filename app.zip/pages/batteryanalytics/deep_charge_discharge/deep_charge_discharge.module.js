(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics.deep_charge_discharge', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics.deep_charge_discharge', {
          url: '/deep_charge_discharge',
          templateUrl: 'app/pages/batteryanalytics/deep_charge_discharge/deep_charge_discharge.html',
          title: 'Deep Charge / Discharge ',
          sidebarMeta: {
			//icon: 'ion-ios-cart',
            order: 900,
          },
        });
  }

})();