(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics.voltage', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics.voltage', {
          url: '/voltage',
          templateUrl: 'app/pages/batteryanalytics/voltage/voltage.html',
          title: 'Voltage',
          sidebarMeta: {
			//icon: 'ion-ios-cart',
            order: 200,
          },
        });
  }

})();