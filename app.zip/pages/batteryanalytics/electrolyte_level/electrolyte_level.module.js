(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics.electrolyte_level', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics.electrolyte_level', {
          url: '/electrolyte_level',
          templateUrl: 'app/pages/batteryanalytics/electrolyte_level/electrolyte_level.html',
          title: 'Electrolyte level',
          sidebarMeta: {
			//icon: 'ion-ios-cart',
            order: 500,
          },
        });
  }

})();