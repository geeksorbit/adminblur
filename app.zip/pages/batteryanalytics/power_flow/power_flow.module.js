(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics.power_flow', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics.power_flow', {
          url: '/power_flow',
          templateUrl: 'app/pages/batteryanalytics/power_flow/power_flow.html',
          title: 'Power Flow',
          sidebarMeta: {
			//icon: 'ion-ios-cart',
            order: 600,
          },
        });
  }

})();