(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics.charging_discharging', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics.charging_discharging', {
          url: '/charging_discharging',
          templateUrl: 'app/pages/batteryanalytics/charging_discharging/charging_discharging.html',
          title: 'Charging / Discharging Rate',
          sidebarMeta: {
		//	icon: 'ion-ios-cart',
            order: 400,
          },
        });
  }

})();