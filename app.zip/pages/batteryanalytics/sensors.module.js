(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics', [
		'BlurAdmin.pages.batteryanalytics.cycles',
		'BlurAdmin.pages.batteryanalytics.voltage',
		'BlurAdmin.pages.batteryanalytics.temperature',
		'BlurAdmin.pages.batteryanalytics.charging_discharging',
		'BlurAdmin.pages.batteryanalytics.electrolyte_level',
		'BlurAdmin.pages.batteryanalytics.power_flow',
		'BlurAdmin.pages.batteryanalytics.current_flow_from_to_battery',
		'BlurAdmin.pages.batteryanalytics.charging_status',
		'BlurAdmin.pages.batteryanalytics.deep_charge_discharge',
  ])
      .config(routeConfig);

  /** @ngInject */
  
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics', {
          url: '/batteryanalytics',
          template : '<ui-view></ui-view>',
          abstract: true,
          title: 'Battery Analytics',
          sidebarMeta: {
            icon: 'ion-speedometer',
            order: 100,
          },
        });
  }

})();