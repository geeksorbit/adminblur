(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics.cycles', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics.cycles', {
          url: '/cycles',
          templateUrl: 'app/pages/batteryanalytics/cycles/cycles.html',
          title: 'Cycles',
          sidebarMeta: {
		//	icon: 'ion-ios-cart',
            order: 100,
          },
        });
  }

})();