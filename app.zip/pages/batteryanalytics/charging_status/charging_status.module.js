(function () {
  'use strict';

  angular.module('BlurAdmin.pages.batteryanalytics.charging_status', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider) {
    $stateProvider
        .state('batteryanalytics.charging_status', {
          url: '/charging_status',
          templateUrl: 'app/pages/batteryanalytics/charging_status/charging_status.html',
          title: 'Charging Status',
          sidebarMeta: {
			//icon: 'ion-ios-cart',
            order: 800,
          },
        });
  }

})();